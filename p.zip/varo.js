import { connect } from 'puppeteer-real-browser'

function waitforme(millisec) {
    return new Promise(resolve => {
        setTimeout(() => { resolve('') }, millisec);
    })
}

const helperFunction = async (newBaseUrl, elements) => {
    var tempData = [];
    // Extracting and logging the text content of each element
    for (const element of elements) {
        // console.log('element',element)sc-i1odl-0
        const identity = await element.$(".sc-i1odl-0")
        const id = await identity?.evaluate(node => node.getAttribute('data-id')) ?? '';
        if (id == undefined || id == null) return '';

        const title = await element.$('.sc-ge2uzh-0')
        const t = await title?.evaluate(node => node.innerText) ?? '';

        const location = await element.$(".sc-ge2uzh-2")
        const l = await location?.evaluate(node => node.innerText) ?? '';

        const description = await element.$(".sc-i1odl-11")
        const d = await description?.evaluate(node => node.innerText) ?? '';

        const price = await element.$('.sc-12dh9kl-3')
        const r = await price?.evaluate(node => node.innerText) ?? ''
        const dollar = r?.includes("USD") ? 18 : 1;
        // console.log('d', dollar)
        const formattedPricing = r?.replaceAll("MN", "")?.replaceAll(",", "")?.replaceAll("USD", "")?.trim();

        const di = await element.$('.sc-1uhtbxc-0')
        const dimedimensionsCard = await di?.evaluate(node => node.innerText) ?? ''

        let formattedMeter = dimedimensionsCard?.trim();
        if (formattedMeter.includes("m²")) {
            formattedMeter = parseFloat(formattedMeter.replaceAll("m²", "").trim());
        } else if (formattedMeter.includes("ha")) {
            formattedMeter = parseFloat(formattedMeter.replaceAll("ha", "").trim()) * 10000;
        }

        const pricingPerMeter = formattedPricing / (formattedMeter * dollar);

        // const elementText = await page.evaluate(element => element.$eval('sc-12dh9kl-3 iqNJlX',node => node.innerText), element);
        tempData.push({
            'page': newBaseUrl,
            'id': id,
            'title': t,
            'pricing': formattedPricing,
            'location': l,
            'description': d,
            'm2': formattedMeter ?? 1,
            'pricingPerMeter': pricingPerMeter ?? 0
        });


    }
    // console.log('tempData', tempData, tempData.length)
    return tempData
}
// http://shnlhwxe-rotate:u6ixvrwq6kch@p.webshare.io:80
const clusterBrowser = async () => {
    let data = await connect({
        // headless : 'auto',
        fingerprint: true,
        args: [
            '--disable-features=IsolateOrigins,site-per-process',
            '--flag-switches-begin --disable-site-isolation-trials --flag-switches-end'
        ],
        // args: [
        //     '--disable-dev-shm-usage',
        //     '--proxy-server=http://shnlhwxe-rotate:u6ixvrwq6kch@p.webshare.io:80'
        // ],
        tf: false, // If a feature you want to use at startup is not working, you can initialize the tf variable false and update it later.
        turnstile: false,
        // proxy: {
        //     host: 'p.webshare.io',
        //     port: '80',
        //     username: 'shnlhwxe-rotate',
        //     password: 'u6ixvrwq6kch'
        // }
    })
        .then(async response => {
            const { page, browser, setTarget } = response
            let baseUrl = "https://www.wg-gesucht.de"
            // await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36');
            // await page.setExtraHTTPHeaders({
            //     'Accept-Language': 'en-US,en;q=0.9',
            //     'Accept-Encoding': 'gzip, deflate, br',
            //     'Connection': 'keep-alive'
            // });
            let url = 'https://bank.varomoney.com/forgot-password'
            await page.goto(url)
        })
        .catch(error => {
            console.log(error.message)
            return "Something went wrong.Try After Sometime or Contact to Developer"
        })
    return data
}
await clusterBrowser().then((res) => {
    console.log('res')
})


